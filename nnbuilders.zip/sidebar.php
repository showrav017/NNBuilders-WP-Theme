<table style="width: 100%; border: 0px;" border="0" cellspacing="0" cellpadding="0">
    <tbody>
    <tr>
        <td width="20%"><strong>Project Updates</strong></td>
        <td width="40%"><strong>NN Builders History</strong></td>
        <td width="20%">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6242.984689035427!2d90.41317451683342!3d23.732155943349017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjPCsDQ0JzAwLjUiTiA5MMKwMjQnNDcuNyJF!5e0!3m2!1sen!2sbd!4v1470070242413" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
        </td>
        <td width="20%"><strong>MD/Chairman Message</strong>

            Message
        </td>
    </tr>
    <tr>
        <td>Notice</td>
        <td></td>
        <td></td>
        <td><strong>GM Message</strong>

            Message
        </td>
    </tr>
    </tbody>
</table>